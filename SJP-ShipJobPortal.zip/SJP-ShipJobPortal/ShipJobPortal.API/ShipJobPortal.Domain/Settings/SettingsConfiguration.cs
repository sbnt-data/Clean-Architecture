﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShipJobPortal.Domain.Settings;

public class EmailSettings
{
    public string FromAddress { get; set; }
    public string AppPassword { get; set; }
}
